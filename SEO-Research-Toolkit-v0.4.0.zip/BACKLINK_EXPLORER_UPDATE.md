# Backlink Explorer v1 – Update

## Installation unter Windows

1. Die laufende Anwendung beenden.
2. Das ZIP direkt nach `C:\Users\olive\downloads\dataforseo` entpacken.
3. Vorhandene Dateien beim Entpacken ersetzen lassen.
4. Einmal `setup.bat` ausführen. Dadurch wird Migration `0003` angewendet.
5. Danach `start.bat` starten und `http://127.0.0.1:8765/` öffnen.

`.env`, die bestehende SQLite-Datenbank und gespeicherte Runs sind nicht im Paket
enthalten und werden daher nicht überschrieben.

## Ersetzte Dateien

- `app/main.py`
- `app/models.py`
- `app/templates/base.html`
- `app/templates/index.html`
- `app/templates/run_detail.html`

## Neue Dateien

- `app/services/backlink_explorer.py`
- `app/static/backlink.css`
- `migrations/versions/0003_backlink_explorer.py`
- `tests/test_backlink_explorer.py`
- `BACKLINK_EXPLORER_UPDATE.md`

## Prüfung

- Python-Syntaxprüfung erfolgreich
- 33 Tests erfolgreich
- Alembic-Upgrade bis `0003 (head)` erfolgreich
- keine kostenpflichtige DataForSEO-Abfrage während Entwicklung oder Tests
