# SERP Explorer v1 – Installation

1. Lokale Anwendung beenden.
2. Dieses ZIP direkt nach `C:\Users\olive\downloads\dataforseo` entpacken und vorhandene Dateien überschreiben.
3. `setup.bat` einmal ausführen. Die Migration `0002` ergänzt nur die neuen SERP-Tabellen; bestehende Runs bleiben erhalten.
4. Danach wie gewohnt `start.bat` starten.

Der SERP Explorer erscheint auf der Startseite. Jeder Abruf muss ausdrücklich über die Kosten-Checkbox bestätigt werden. Das Paket enthält keine `.env`, keine Datenbank und keine Zugangsdaten.

## Verifikation

- 13 automatisierte Tests bestanden.
- Migrationen auf einer frischen SQLite-Datenbank bis `0002 (head)` erfolgreich.
- Kein echter DataForSEO-Aufruf wurde während Entwicklung oder Tests ausgeführt.
